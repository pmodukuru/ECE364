
def getSummary():
    pass


def saveContinuousData(start, end, targetFileName):
    pass


def getSampledSignal(signalName):
    pass


def identifyCheapest(componentSet):
    pass


def getComponentsToAdd():
    pass
