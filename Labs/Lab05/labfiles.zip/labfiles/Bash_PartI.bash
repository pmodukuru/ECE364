#! /bin/bash

#----------------------------------
# $Author$
# $Date$
#----------------------------------

function part_a 
{               
    # Fill out your answer here
    return                      
}                               

function part_b
{              
    # Fill out your answer here
    return                     
}                              

function part_c
{
    # Fill out your answer here
    return
}

function part_d
{
    # Fill out your answer here
    return
}

function part_e
{
    # Fill out your answer here
    return
}

# To test your function, you can call it below like this:
#
# part_a