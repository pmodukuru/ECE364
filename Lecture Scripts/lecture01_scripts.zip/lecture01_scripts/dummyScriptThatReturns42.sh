# This is a dummy script that returns 42.

exit 42