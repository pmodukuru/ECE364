#!/usr/local/bin/python3.4

"""
Script samples for ECE 364: THIS IS NOT A GOOD SCRIPT FORMAT.
"""

x1 = 3
x2 = 10

total = x1 + x2
print("The sum of {0} and {1} is {2}".format(x1, x2, total))
